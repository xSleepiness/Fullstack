package com.FullStack.GestionUsuarios.Model;

import jakarta.persistence.*;
import lombok.*;
@Table(name = "usuarios")
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String telefono;
    
    @Builder.Default
    private boolean activo = true;
    
}
